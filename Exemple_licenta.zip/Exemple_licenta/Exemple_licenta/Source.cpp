#include <iostream>
#include <list>
#include <string>
using namespace std;

class Vehicul {
protected:
    string marca;
    string model;

public:
    // Constructor
    Vehicul(const string& marca, const string& model) {
        setMarca(marca);
        setModel(model);
    }

  //  virtual ~Vehicul() {} // Destructor virtual

    string getMarca() const {
        return marca;
    }

    void setMarca(const string& marca) {
        this->marca = marca;
    }

    string getModel() const {
        return model;
    }

    void setModel(const string& model) {
        this->model = model;
    }

    // Metoda virtuala pura pentru descriere
    virtual string descriere() const = 0;
};

class Masina : public Vehicul {
public:
    string culoare;

    // Constructor
    Masina(const string& marca, const string& model, const string& culoare)
        : Vehicul(marca, model) {
        setCuloare(culoare);
    }

    string getCuloare() const {
        return culoare;
    }

    void setCuloare(const string& culoare) {
        this->culoare = culoare;
    }

    // Suprascrierea functiei descriere
    string descriere() const override {
        return "Masina: " + getMarca() + " " + getModel() + ", Culoare: " + getCuloare();
    }
};

class Bicicleta : public Vehicul {
public:
    int nr_roti;

    Bicicleta(const string& marca, const string& model, const int nr_roti)
        : Vehicul(marca, model) {
        setNr_roti(nr_roti);
    }

    int getNr_roti() const {
        return nr_roti;
    }

    void setNr_roti(int nr_roti) {
        this->nr_roti = nr_roti;
    }

    string descriere() const override {
        return "Bicicleta: " + getMarca() + " " + getModel() + ", Nr roti: " + to_string(nr_roti);
    }
};

int main() {
    list<Vehicul*> lista_vehicule;
    lista_vehicule.push_back(new Masina("Toyota", "Corolla", "albastra"));
    lista_vehicule.push_back(new Bicicleta("Trek", "Mountain Bike", 2));

    //reprezentarea polimorfismului 
    for (auto vehicul : lista_vehicule) {
        cout << vehicul->descriere() << endl;
    }

    for (auto vehicul : lista_vehicule) {
        delete vehicul;
    }

    return 0;
}
