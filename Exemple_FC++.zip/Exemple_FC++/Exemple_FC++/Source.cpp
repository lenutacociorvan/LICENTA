#include<iostream>
#include "prelude.h"
#include <math.h>
using namespace fcpp;

/*
	https://people.cs.umass.edu/~yannis/fc++/tutorial.html#Sec2
*/


//functii definite

struct Sin {
	template <class T> struct Sig : public FunType<T, T> {};

	template <class T>
	T operator()(const T& x) const {
		return sin(x);
	}
} sinus;


template <class T>
void print(List<T> l, const char* sep = " ") {
	copy(l.begin(), l.end(), std::ostream_iterator<T>(std::cout, sep));
}

bool estePalindrom(int x) {
	int cx = x, ogl = 0;
	while (cx) {
		ogl = ogl * 10 + cx % 10;
		cx /= 10;
	}
	return x == ogl;
}


int sirRec(int an, int n) {//a_(n+1)=f(a_n)+g(n)
	return an + n * n;
}


//testeaza daca este atins obiectivul |f(x)-o| <= p
struct fObiectiv : public CFunType<double, Fun1<double, double>, bool> {
	double precizie;
	double obiectiv;
	Fun1<double, double> f1;
	fObiectiv(double o, double p, Fun1<double, double> f) : precizie(p), obiectiv(o), f1(f) {}
	bool operator()(double x) const {
		return std::abs(f1(x) - obiectiv) <= precizie;
	}
};



struct recRedical : public CFunType<double, double, double> {// y=(y+x/y)/2     a_(n+1)=(a_n+x/a_n)2, a_0=1  a_n->sqrt(x)
	double operator()(double x, double y) const {
		return 0.5 * (y + x / y);
	}
};

double radical(double x, double precizie) {
	return until(fObiectiv(x, precizie, [](double a) {return a * a; }), curry2(recRedical(), x), 1.0);
}



struct Factorial : public CFunType<int, int> {
	int operator()(int x) const {
		if (x == 0) { return 1; }
		else { return x * (*this)(x - 1); }
	}
} fact;


int main() {
	/*List<int> lp = filter(ptr_to_fun(&estePalindrom), enumFromTo(1, 1000));
	print(lp);
	*/

	/*Fun2<int, int, int> f2 = ptr_to_fun(&sirRec);
	Fun1<int, int> f1 = f2(_, 2);

	std::cout << std::endl << f1(5) << std::endl;

	std::cout <<std::endl<< f2(2, 3) << std::endl;
*/
	List<int> an = scanl1(ptr_to_fun(&sirRec), enumFromTo(1, 100));
	print(an);

	//List<double> valori(listUntil(Never1(), curry2(radRec(), 101), 1.0));
	//print(valori);
	std::cout << radical(101, 0.001) << std::endl;

	std::cout << fact(5) << std::endl;



	Factorial fa, fb;
	Fun1<int, int> f = makeFun1(fa);
	/**/




	/*
		List<int> m = list_with(4, 5, 6);
		List<int> n = list_with(1, 2, 3);
		f(zipWith(_, m, n));

		int a[5] = { 1, 2, 3, 4, 5 };
		std::vector<int> v(a, a + 5);
		std::transform(v.begin(), v.end(), v.begin(), fcpp::plus(3));
		std::copy(v.begin(), v.end(), std::ostream_iterator<int>(std::cout, " "));
		std::cout << std::endl;*/
	return 0;
}
/*
int main() {
	List<int> lp = filter(ptr_to_fun(&estePalindrom), enumFromTo(1, 500));
	print(lp);
}
*/

/*
int main() {
	List<int> li = enumFrom(1);
	List<bool> lb = take(5, map(odd, li));
	copy(lb.begin(), lb.end(), std::ostream_iterator<int>(std::cout, " "));

	return 0;
}
*/


/*
struct Divizibil : public CFunType<int, int, bool> {
	bool operator()(int x, int y) const
	{
		return x % y == 0;
	}
} divizibil;

struct Divizori : public CFunType<int, OddList<int> > {
	OddList<int> operator()(int x) const {
		return filter(curry2(divizibil, x), enumFromTo(1, x));
	}
} divizori;

struct Prim : public CFunType<int, bool> {
	bool operator()(int return divizori(x) == cons(1, cons(x, NIL));
	}x) const {
		
} prim;

struct NrPrime : public CFunType<int, OddList<int> > {
	OddList<int> operator()(int n) const {
		return take(n, filter(prim, enumFrom(1)));
	}
} prime;


int main() {
	List<int> l = prime(10);
	//std::cout << at(l, 10) << std::endl;
	//List<int>::iterator i = find(l.begin(), l.end(), 5);
	copy(l.begin(), l.end(), std::ostream_iterator<int>(std::cout, " "));
}
*/
