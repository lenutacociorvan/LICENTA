from functools import reduce,partial
a = 0
add_pure_lambda = lambda x, y: x + y
add_impure_lamda = lambda z: z + a

print(add_pure_lambda(4, 5)) #
print(add_impure_lamda(4))
a = 5
print(add_impure_lamda(4))

def factorial_functional(number):
    return reduce(lambda x, y: x * y, range(1, number + 1), 1)
print(factorial_functional(5))  # Output: 120

#Evitarea starii partajate
increment = lambda count: count + 1
nr = 7
print(increment(nr))  # Output: 8

#Folosirea starii partajate
state = {'index': 0}
def count(state):
    state['index'] += 1
    return state['index']

#Functie partiala care foloseste starea partajata
count_partial = partial(count, state)

print(count_partial())  # Output: 1
print(count_partial())  # Output: 2


#Imutabilitatea
print("Imutabilitate: ")


def add(t):
    return t + ('element_nou')

original_tuple = ('a', 'b', 'c')
modified_tuple = add(original_tuple)

print(original_tuple)  # iesiri: ('a', 'b', 'c')
print(modified_tuple)  # iesiri: ('a', 'b', 'c', 'element_nou')