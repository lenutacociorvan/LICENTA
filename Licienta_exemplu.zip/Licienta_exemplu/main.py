class Vehicul:
    def __init__(self, marca, model):
        self.marca = marca
        self.model = model

    def descriere(self):
        raise NotImplementedError()

class Masina(Vehicul):
    def __init__(self, marca, model, culoare):
        super().__init__(marca, model)
        self.culoare = culoare

    def descriere(self):
        return f"Masina: {self.marca} {self.model}, Culoare: {self.culoare}"

class Bicicleta(Vehicul):
    def __init__(self, marca, model, nr_roti):
        super().__init__(marca, model)
        self.nr_roti = nr_roti

    def descriere(self):
        return f"Bicicleta: {self.marca} {self.model}, Nr_roti: {self.nr_roti}"

lista_vehicule = [
    Masina("Toyota", "Corolla", "albastra"),
    Bicicleta("Mountain Bike", "Trek", 2),
]

for vehicul in lista_vehicule:
    print(vehicul.descriere())


